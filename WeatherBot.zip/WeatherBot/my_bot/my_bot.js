const discord = require('discord.js')
const client = new discord.Client()
const weather = require('weather-js')


client.on('ready', () => {
    console.log("Connect as " + client.user.tag)

    client.user.setActivity("twitch.tv/cptchuncho", {type: "WATCHING"})

    client.guilds.forEach((guild) => {
        console.log(guild.name)
        guild.channels.forEach((channel) => {
            console.log(` - ${channel.name} ${channel.type} ${channel.id}`)
        })
        // General Channel id 658539547512274954


    })

    let generalChannel = client.channels.get("658539547512274954")
    const attachment = new discord.Attachment("https://cdn.discordapp.com/attachments/658526431227150339/658536643476848662/IMG_20191223_000915_292.jpg")
   // generalChannel.send("Follow twitch.tv/cptchuncho to look as sexy as him!!!!!")
  //  generalChannel.send(attachment)
})

client.on('message', (receivedMessage) => {
    if (receivedMessage.channel.id == 658539547512274954){
        if (receivedMessage.author == client.user){
         return
      }
     //receivedMessage.channel.send("Message received, " + receivedMessage.author.toString() + ": " + receivedMessage.content)

    // receivedMessage.react("🍆")
    }   
    if (receivedMessage.content.startsWith("&")){
      processCommand(receivedMessage)
    }
})

function processCommand(receivedMessage){
    let fullCommand = receivedMessage.content.substr(1)
    let splitCommand = fullCommand.split(" ")
    let primaryCommand = splitCommand[0]
    let arguments = splitCommand.slice(1)

    if (primaryCommand == "help"){
        helpCommand(arguments, receivedMessage)
    } else if (primaryCommand == "multiply"){
        multiplyCommand(arguments, receivedMessage)
    }else if (primaryCommand == "weather"){
        weatherCommand(arguments, receivedMessage)
    }else if (primaryCommand == "add"){
        addCommand(arguments, receivedMessage)
    } else if (primaryCommand == "stocks"){
        stockcommand(arguments, receivedMessage)
    } else {
      receivedMessage.channel.send("Unknown Message. try &help, &multiply or &add")  
    }
}

function multiplyCommand(arguments, receivedMessage){
    if (arguments.length < 2){
        receivedMessage.channel.send("Not enough arguments try `&muliply 2 10`")
        return
    }
    let product = 1
    arguments.forEach((value) => {
        product = product * parseFloat(value)
    })
    receivedMessage.channel.send("The product of " + arguments + " is " + product.toString())
}

function addCommand(arguments, receivedMessage){
    if (arguments.length < 2){
        receivedMessage.channel.send("Not enough arguments try `&add 2 2`")
        return
    }
    let sum = 0
    arguments.forEach((value) => {
        sum = sum + parseFloat(value)
    })
    receivedMessage.channel.send("The sum of " + arguments + " is " + sum.toString())
}

function helpCommand(arguments, receivedMessage){
    if (arguments.length == 0){
      receivedMessage.channel.send("I'm not sure what you need help with!")  
    } else {
        receivedMessage.channel.send("It looks like you need help with: " + arguments)
    }
}

function weatherCommand(arguments, receivedMessage){
    weather.find({search: arguments.join(" "), degreeType: 'C'}, function(err, result){
        if (err) receivedMessage.channel.send(err)

        var current = result[0].current
        var location = result[0].location

         const exampleEmbed = new discord.RichEmbed()
            .setColor(0x00AE86)
            .setAuthor(`Weather for ${current.observationpoint}`)
            .setDescription(`**${current.skytext}**`)
            .setThumbnail(current.imageURL)
            .addField('Timezone', `UTC ${location.timezone}`, true)
            .addField('Degree Type', location.degreetype, true)
            .addField('Temperature', `${current.temperature} Degrees`, true)
            .addField('Feels Like', `${current.feelslike} Degrees`, true)
            .addField('Winds', current.winddisplay, true)
            .addField('Humidity', `${current.humidity}%`, true);

        receivedMessage.channel.send(exampleEmbed)
    })
}

function stocksCommand(arguments, receivedMessage){
    
}



client.login("NjU4NTI3MTg3Mzk3NTA5MTMx.XgBDZQ.xsC-yD4flIWd5qTReHY1zbZL2pU")

// path: C:\Users\david\OneDrive\Desktop\Coding\Projects\my_bot